//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int a=43089, sum=0, i=0, k=10;
//    while (a>0) {
//        i++;
//        sum += a % k;
//        a /= 10;
//    }
//    printf("%d %d", sum, i);

//    return 0;
//}