//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    const int N=10;
//    int i,  k=0;
//    int a[N] = {1, 2, 3, 5, 5, 5, 6, 7, 8, 9};
//
//    for(i=1; i<N-1; i++) {
//if (a[i]>a[i-1] && a[i]>a[i+1])
//{
//    k++;
//}
//    }
//    printf("%d", k);
//    return 0;
//}
