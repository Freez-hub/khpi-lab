//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    const int N=10000;
//    int a[N], sum=0, sum2=0, k=0;
//    for (int i = 0; i < 10000; i++)
//    {
//        int j=i;
//
//        if (j > 0)  {
//            sum += j%10;
//            j /= 10;
//        }
//        if (j > 0)  {
//            sum += j%10;
//            j /= 10;
//        }
//        if (j > 0)  {
//            sum2 += j%10;
//            j /= 10;
//        }
//        if (j > 0)  {
//            sum2 += j%10;
//            j /= 10;
//        }
//        if(sum==sum2)
//        {
//           a[k]=i;
//           k++;
//        }
//        sum2=0;
//        sum=0;
//
//    }
//    for (int i = 1; i < N; i++)
//    {
//        printf("%d ", a[i]);
//    }
//    printf("%d ", k);
//
//    return 0;
//}
//
//
//
