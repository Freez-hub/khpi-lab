//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    const int N=10;
//    int a[N];
//    for (int i = 0; i < N; i++)
//    {
//        if (i == 0 || i == 1)
//            a[i] = 1;
//        else
//            a[i]=i +(i-1);
//    }
//    for (int i = 1; i < N; i++)
//    {
//        printf("%d ", a[i]);
//    }
//
//    return 0;
//}
//
