//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int n=3;
//    float start=1000, proc=1.05;
//    for(int i=0; i<n; i++)
//        start*=proc;
//    printf("%f", start);
//    return 0;
//}