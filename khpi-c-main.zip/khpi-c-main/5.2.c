//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int a=1, suba, sum=0, i=0, k;
//    suba=a;
//    while (a>0) {
//        i++;
//        a /= 10;
//    }
//    while (i>0)
//    {
//        k=pow(10, i);
//        sum += suba % 10*k;
//        suba %= k;
//        suba/=10;
//       i--;
//    }
//    sum/=10;
//    printf("%d", sum);
//    return 0;
//}