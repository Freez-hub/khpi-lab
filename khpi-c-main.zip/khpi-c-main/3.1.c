//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int x, a=490;
//    x=(a%100-a%10)/10;
//
//    printf("%d", x);
//    return 0;
//}
