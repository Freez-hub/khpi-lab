//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int x, a=4998;
//    x=a%10;
//    x+=(a%100-a%10)/10;
//    x+=(a%1000-a%100)/100;
//    x+=(a-a%1000)/1000;
//    printf("%d", x);
//    return 0;
//}
