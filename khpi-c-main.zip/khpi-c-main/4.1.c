//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int a=439;
//    if (a%10==(a%100-a%10)/10 || a%10==(a%1000-a%100)/100 || (a%100-a%10)/10 == (a%1000-a%100)/100 )
//    printf("yes");
//    else
//        printf("no");
//    return 0;
//}