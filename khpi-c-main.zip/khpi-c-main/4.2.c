//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int a=430;
//    if ((a%10<=(a%100-a%10)/10 && a%10==(a-a%100)/100)) {
//        printf("3");
//    }
//        else
//        {
//            if ((a % 100 - a % 10) / 10 <= (a - a % 100) / 100 && (a % 100 - a % 10) / 10 <= a % 10) {
//                printf("2");
//            }
//                else
//                {
//                    printf("1");
//                }
//            }
//    return 0;
//}