//#include <stdio.h>
//#include <math.h>
//int main()
//{
//    int a=1, x;
//    a--;
//    x=a/100+1;
//    printf("%d", x);
//    return 0;
//}